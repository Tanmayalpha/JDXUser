package com.jdxconnect.user

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
