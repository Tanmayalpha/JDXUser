//Recruiter Drawer Screen Icons
String profileIconR = "assets/DrawerAssets/profileIcon.png";
String postjobIconR = 'assets/DrawerAssets/postjobIcon.png';
String appliedIconR = "assets/DrawerAssets/applied.png";
String changepasswordIconR = "assets/DrawerAssets/lockIcon.png";
String shareappIconR = "assets/DrawerAssets/shareappIcon.png";
String searchIconR = "assets/DrawerAssets/searchIcon.png";
String notificationIconR = "assets/DrawerAssets/notificationIcon.png";
String contactusIconR = "assets/DrawerAssets/contactusIcon.png";
String privactpolicyIconR = "assets/DrawerAssets/privacypolicyIcon.png";
String termsandconditionIconR = "assets/DrawerAssets/termsandconditionIcon.png";
String signoutIconR = "assets/DrawerAssets/signoutIcon.png";


//Job Seeker Drawer Screen Icons
String profileIconJ = "assets/DrawerAssets/profileIcon.png";
String myjobIconJ = "assets/DrawerAssets/myjobIcon.png";
String appliedjobIconJ = "assets/DrawerAssets/appliedjobIcon.png";
String allrecruiterIconJ = 'assets/DrawerAssets/allrecruiterIconJ.png';
String changepasswordIconJ = "assets/DrawerAssets/lockIcon.png";
String notificationIconJ = "assets/DrawerAssets/notificationIcon.png";
String shareappIconJ = "assets/DrawerAssets/shareappIcon.png";
String contactusIconJ = "assets/DrawerAssets/contactusIcon.png";
String privactpolicyIconJ = "assets/DrawerAssets/privacypolicyIcon.png";
String supportandhelpJ = "assets/DrawerAssets/supportIconJ.png";
String termsandconditionIconJ = "assets/DrawerAssets/termsandconditionIcon.png";
String signoutIconJ = "assets/DrawerAssets/signoutIcon.png";


//Post Job Screens Icons

String locationIcon = "assets/ProfileAssets/locationIcon.png";
String ruppeeIcon = "assets/ProfileAssets/ruppeeIcon.png";
String experienceIcon = "assets/ProfileAssets/experienceIcon.png";
String editIcon = "assets/ProfileAssets/editIcon.png";
String deleteIcon = "'assets/DrawerAssets/deleteIcon.png'";
String sharefileIcon = "assets/ProfileAssets/sharefileIcon.png";





