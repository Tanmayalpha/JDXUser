import 'dart:convert';
import 'dart:io';

import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:job_dekho_app/Jdx_screens/parcel_history.dart';
import 'package:job_dekho_app/Model/bannerModel.dart';
import 'package:job_dekho_app/Model/notificationModel.dart';
import 'package:job_dekho_app/Model/studentModel.dart';
import 'package:job_dekho_app/Utils/api_path.dart';
import 'package:job_dekho_app/Jdx_screens/MyProfile.dart';
import 'package:http/http.dart' as http;
// import 'package:job_dekho_app/Jdx_screens/mywallet.dart';
import 'package:job_dekho_app/Views/Student/studentDetailScreen.dart';
import 'package:job_dekho_app/Jdx_screens/notification_Screen.dart';
import 'package:place_picker/entities/location_result.dart';
import 'package:place_picker/widgets/place_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../Model/ParcelHistoryModel.dart';
// import '../Model/Parcelhistory_model.dart';
import 'Dashbord.dart';
import '../Model/myPlanModel.dart';
import '../Services/push_notification_service.dart';
import '../Utils/color.dart';
import 'signup_Screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {

  TextEditingController addressC = TextEditingController();
  TextEditingController nameC = TextEditingController();
  TextEditingController mobileC = TextEditingController();
  TextEditingController pincodeC = TextEditingController();
  TextEditingController cityC = TextEditingController();
  TextEditingController stateC = TextEditingController();
  TextEditingController buildingC = TextEditingController();
  TextEditingController countryC = TextEditingController();
  double lat = 0.0;
  double long = 0.0;
  // String radioButtonItem = 'ONE';
  int id = 0;


  List<String> myIds = [];


  String? planStatus;


  MyPlanModel? myPlanModel;
  var myPlanId;

  bool  ResponseCode = false;

  ParcelhistoryModel? parcelhistory;
  parcelHistory() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    String? userid = preferences.getString("userid");
    var headers = {
      'Cookie': 'ci_session=c4d89ea1aafd386c2dd6a6d1913c38e59c817e3d'
    };
    var request = http.MultipartRequest('POST', Uri.parse('${ApiPath.baseUrl}payment/parcel_history'));
    request.fields.addAll({
      'user_id': "210"
    });
    print("thi555555555555555=?>${request.fields}");
    request.headers.addAll(headers);
    http.StreamedResponse response = await request.send();
    print("thi555555555555555=?>${response.statusCode}");
    if (response.statusCode == 200) {
      var finalResult = await response.stream.bytesToString();
      final jsonResponse = ParcelhistoryModel.fromJson(json.decode(finalResult));
      print("aaaaaaaaaaaaaaaaaa===========>${jsonResponse}");
      print("aaaaaaaaaaaaaaaaaa===========>${finalResult}");
      setState(() {
        parcelhistory = jsonResponse;
      });

    }
    else {
      print(response.reasonPhrase);
    }

  }

  void initState() {
    // TODO: implement initState
    super.initState();
    Future.delayed(Duration(milliseconds: 300),(){
      return parcelHistory();

    });
  }

  // @override
  // void initState() {
  //   // TODO: implement initState
  //   PushNotificationService pushNotificationService = new PushNotificationService(context: context);
  //   pushNotificationService.initialise();
  //   super.initState();
  //   Future.delayed(Duration(milliseconds: 300),(){
  //   });
  //
  //   // Future.delayed(Duration(seconds: 1),(){
  //   //   return getParentCheckStudent();
  //   // });
  //
  //
  //
  //   Future.delayed(Duration(milliseconds: 500),(){
  //     return getbanner();
  //   });
  //   Future.delayed(Duration(milliseconds: 300),(){
  //   });
  // }

  BannerModel? bannerModel;
  getbanner()async {
    print("banner section");
    var headers = {
      'Cookie': 'ci_session=055b59d73b5b89adf30482e59e4eb111b23c7f4f'
    };
    var request = http.Request('GET', Uri.parse('${ApiPath.baseUrl}get_banners_user'));
    request.headers.addAll(headers);
    http.StreamedResponse response = await request.send();
    if (response.statusCode == 200) {
      var finalResult = await response.stream.bytesToString();
      final jsonResponse = BannerModel.fromJson(json.decode(finalResult));
      setState(() {
        bannerModel = jsonResponse;
      });
    }
    else {
      print(response.reasonPhrase);
    }
  }

  int? currentindex;

  showChildDialog()async{
    var result = await Navigator.push(context, MaterialPageRoute(builder: (context) => SignUpScreen()));
    if(result == true){
    //  getbanner();
    }
  }

  Future _refreshLocalGallery() async{
    getbanner();
  }

  Future<bool> showExitPopup() async {
    return await showDialog( //show confirm dialogue
      //the return value will be from "Yes" or "No" options
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Exit App',style: TextStyle(fontFamily: 'Lora'),),
        content: Text('Do you want to exit an App?',style: TextStyle(fontFamily: 'Lora'),),
        actions:[
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: primaryColor),
            onPressed: () => Navigator.of(context).pop(false),
            //return false when click on "NO"
            child:Text('No',style: TextStyle(fontFamily: 'Lora'),),
          ),

          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: primaryColor),
            onPressed: (){
              exit(0);
              // Navigator.pop(context,true);
              // Navigator.pop(context,true);
            },
            //return true when click on "Yes"
            child:Text('Yes',style: TextStyle(fontFamily: 'Lora'),),
          ),
        ],
      ),
    )??false; //if showDialouge had returned null, then return false
  }

    @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: _refreshLocalGallery,
      child: WillPopScope(
        onWillPop: showExitPopup,
        child: Scaffold(
          // appBar: AppBar(
          //   // leading: GestureDetector(
          //   //   onTap: (){
          //   //     Get.to(MyStatefulWidget());
          //   //   },
          //   //   child: Icon(Icons.arrow_back),
          //   //   // child: Image.asset('assets/ProfileAssets/menu_icon.png', scale: 1.6,),
          //   // ),
          //   elevation: 0,
          //   backgroundColor: primaryColor,
          //   title: Text("Home",style: TextStyle(fontFamily: 'Lora'),),
          //   centerTitle: true,
          //   actions: [
          //     Padding(
          //       padding:  EdgeInsets.only(right: 10),
          //       child: InkWell(
          //           onTap: (){
          //             Navigator.push(context, MaterialPageRoute(builder: (context) => NotificationScreen()));
          //           },
          //           child: Icon(Icons.notifications,color: Colors.white,)),
          //     )
          //   ],
          // ),

          // backgroundColor: primaryColor,
  // floatingActionButton: FloatingActionButton(
  //     backgroundColor: primaryColor,
  //   onPressed: (){
  //     // if(ResponseCode == true){
  //     //   var snackBar = SnackBar(
  //     //     content: Text('Add limit exceed'),
  //     //   );
  //     //   ScaffoldMessenger.of(context).showSnackBar(snackBar);
  //     // }
  //    // else{
  //       if(planStatus == "1"){
  //           if(ResponseCode == true){
  //               var snackBar = SnackBar(
  //                 content: Text('Add limit exceed',style: TextStyle(fontFamily: 'Lora'),),
  //               );
  //               ScaffoldMessenger.of(context).showSnackBar(snackBar);
  //           }
  //           else {
  //             showChildDialog();
  //           }
  //       }
  //       else{
  //         var snackBar = SnackBar(
  //           content: Text('Please take subscription',style: TextStyle(fontFamily: 'Lora'),),
  //         );
  //         ScaffoldMessenger.of(context).showSnackBar(snackBar);
  //         setState(() {
  //           Navigator.push(context, MaterialPageRoute(builder: (context) => SubscriptionPage()));
  //         });
  //       }
  //   //  }
  // },child: Text("Add Child",textAlign: TextAlign.center,style: TextStyle(fontSize: 12,fontFamily: 'Lora'),),),
          body:SingleChildScrollView(
            child: Column(
              children: [
                Container(
                  width: MediaQuery.of(context).size.width,
                  padding: EdgeInsets.symmetric(vertical: 18,horizontal: 14),
                  height: MediaQuery.of(context).size.height/1.1,
                  decoration : BoxDecoration(
                      color: Color(0xffF9F9F9),
                      borderRadius: BorderRadius.only(topRight: Radius.circular(0))
                  ),
                  child:ListView(
                    shrinkWrap: true,
                   physics: ScrollPhysics(),
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Material(
                            elevation: 0,
                            borderRadius: BorderRadius.circular(0),
                            child: Container(
                              width: MediaQuery.of(context).size.width / 1.2,
                              height: 60,
                              child: TextField(
                                readOnly: true,
                                controller: addressC,
                                maxLines: 1,
                                onTap: (){
                                  _getLocation();
                                },
                                textInputAction: TextInputAction.next,
                                decoration: InputDecoration(
                                  border: const OutlineInputBorder(
                                      borderSide: BorderSide.none
                                  ),
                                  hintText: "Current Location",
                                  prefixIcon: Image.asset('assets/ProfileAssets/locationIcon.png', scale: 1.5, color: primaryColor,),
                                ),
                              ),
                            ),
                          ),
                          InkWell(
                              onTap: (){
                                Navigator.push(context, MaterialPageRoute(builder: (context) => NotificationScreen()));
                              },
                              child: Icon(Icons.notification_add_outlined,color: Colors.black,))
                        ],
                      ),
                      SizedBox(height: 20,),

                      Padding(
                        padding: const EdgeInsets.all(5.0),
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: splashcolor,
                          ),

                          width: MediaQuery.of(context).size.width/2.5,
                          height: 50,
                          child: TextField(
                            decoration: InputDecoration(
                              border: OutlineInputBorder(
                                borderSide: BorderSide.none,
                              ),
                              hintText: "Search ",
                              prefixIcon: Icon(Icons.search,  color: primaryColor,),
                            ),),),
                      ),
                      // Text("Welcome back ",style: TextStyle(color: Colors.black,fontSize: 18,fontWeight: FontWeight.w600,fontFamily: 'Lora'),),
                      SizedBox(
                        height: 15,
                      ),
                   // bannerModel == null ? Center(child: CircularProgressIndicator(),) : bannerModel!.data!.length == 0 ?
                   // Center(child: Text("No slider to show",style: TextStyle(fontFamily: 'Lora'),),),
                      //  :  Container(
                      //   height: 180,
                      //   width: double.infinity,
                      //   // width: double.infinity,
                      //   child:  CarouselSlider(
                      //     options: CarouselOptions(
                      //       viewportFraction: 1.2,
                      //       initialPage: 0,
                      //       enableInfiniteScroll: true,
                      //       reverse: false,
                      //       autoPlay: true,
                      //       autoPlayInterval: Duration(seconds: 3),
                      //       autoPlayAnimationDuration:
                      //       Duration(milliseconds: 120),
                      //       enlargeCenterPage: false,
                      //       scrollDirection: Axis.horizontal,
                      //       height: 180,
                      //       onPageChanged: (position, reason) {
                      //         setState(() {
                      //           currentindex = position;
                      //         });
                      //         print(reason);
                      //         print(CarouselPageChangedReason.controller);
                      //       },
                      //     ),
                      //     items: bannerModel!.data!.map((val) {
                      //       print("ooooooo ${ApiPath.imgUrl}${val.image}");
                      //       return Container(
                      //         width: MediaQuery.of(context).size.width,
                      //         decoration: BoxDecoration(
                      //             borderRadius: BorderRadius.circular(20)
                      //         ),
                      //         // height: 180,
                      //         // width: MediaQuery.of(context).size.width,
                      //         child: ClipRRect(
                      //             borderRadius: BorderRadius.circular(20),
                      //             child: Image.network(
                      //               "${ApiPath.imgUrl}${val.image}",
                      //               fit: BoxFit.fill,
                      //             )),
                      //       );
                      //     }).toList(),
                      //   ),
                      //
                      //   // ListView.builder(
                      //   //   scrollDirection: Axis.horizontal,
                      //   //   shrinkWrap: true,
                      //   //   //physics: NeverScrollableScrollPhysics(),
                      //   //   itemCount: homeSliderList!.banneritem!.length,
                      //   //   itemBuilder: (context, index) {
                      //   //     return
                      //   //
                      //   //     //   InkWell(
                      //   //     //   onTap: () {
                      //   //     //     // Get.to(ProductListScreen(
                      //   //     //     //     parentScaffoldKey: widget.parentScaffoldKey));
                      //   //     //     widget.callback!.call(11);
                      //   //     //   },
                      //   //     //   child: Image.network("${Urls.imageUrl}${sliderBanner!.banneritem![0].bimg}"),
                      //   //     //   // Container(
                      //   //     //   //   margin: getFirstNLastMergin(index, 5),
                      //   //     //   //   width: MediaQuery.of(context).size.width * 0.8,
                      //   //     //   //   decoration: BoxDecoration(
                      //   //     //   //       color: (index + 1) % 2 == 0
                      //   //     //   //           ? AppThemes.lightRedColor
                      //   //     //   //           : AppThemes.lightYellowColor,
                      //   //     //   //       borderRadius:
                      //   //     //   //           BorderRadius.all(Radius.circular(10))
                      //   //     //   //   ),
                      //   //     //   // ),
                      //   //     // );
                      //   //   },
                      //   // ),
                      // ),
                      Container(
                        height: 150,
                        width: MediaQuery.of(context).size.width,
                        child: ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: Image.network("https://d3jmn01ri1fzgl.cloudfront.net/photoadking/webp_thumbnail/5ffd7bb2d8963_json_image_1610447794.webp",fit: BoxFit.fill,)),
                      ),
                      SizedBox(height: 20,),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('Parcel History',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                          InkWell(
                            onTap: (){
                              Get.to(ParcelHistory());

                            },
                              child: Text('View All',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 18,color: primaryColor),)),
                        ],
                      ),
                      Container(
                        height: 300,
                     width: double.infinity,
                     child:
                     parcelhistory == null ? Center(child: CircularProgressIndicator(),) : parcelhistory! == null  ? Center(child: Text("No data to show",style: TextStyle(fontFamily: 'Lora'),),) :
                     SingleChildScrollView(
                       child: ListView.builder(
                              shrinkWrap: true,
                              physics: NeverScrollableScrollPhysics(),
                              scrollDirection: Axis.vertical,
                              itemCount: parcelhistory!.data!.length,
                              itemBuilder: (c,i){
                                return Padding(
                                  padding: EdgeInsets.only(bottom: 0),
                                  child: InkWell(
                                    onTap: (){
                                    },
                                    child: Card(
                                      elevation: 1,
                                      shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(10)
                                      ),
                                      child: Container(
                                        padding: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(10),
                                        ),
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            CircleAvatar(backgroundImage: NetworkImage("https://images.unsplash.com/photo-1547721064-da6cfb341d50"),),
                                            SizedBox(height: 10,),
                                            Column(
                                              mainAxisAlignment: MainAxisAlignment.start,
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Text("Order ID",style: TextStyle(color: Colors.black,fontSize: 14,fontWeight: FontWeight.w500,fontFamily: 'Lora'),),
                                                Text("${parcelhistory!.data![i].orderId}",style: TextStyle(color: Colors.black,fontWeight: FontWeight.w600,fontSize: 16,fontFamily: 'Lora'),),

                                                // Text("202",style: TextStyle(color: Colors.black,fontSize: 14,fontWeight: FontWeight.w500,fontFamily: 'Lora'),),
                                                Text("Total Amount",style: TextStyle(color: Colors.black,fontSize: 14,fontWeight: FontWeight.w500,fontFamily: 'Lora'),),
                                                Text("${parcelhistory!.data![i].orderAmount}",style: TextStyle(color: Colors.black,fontWeight: FontWeight.w600,fontSize: 16,fontFamily: 'Lora'),),
                                              ],
                                            ),
                                            Column(
                                              mainAxisAlignment: MainAxisAlignment.start,
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Text("Parcel Count",style: TextStyle(color: Colors.black,fontSize: 14,fontWeight: FontWeight.w500,fontFamily: 'Lora'),),
                                                Text("${parcelhistory!.data![i].userId}",style: TextStyle(color: Colors.black,fontWeight: FontWeight.w600,fontSize: 16,fontFamily: 'Lora'),),
                                                Text("Order Date",style: TextStyle(color: Colors.black,fontSize: 14,fontWeight: FontWeight.w500,fontFamily: 'Lora'),),
                                                Text("${parcelhistory!.data![i].onDate}",style: TextStyle(color: Colors.black,fontWeight: FontWeight.w600,fontSize: 16,fontFamily: 'Lora'),),

                                              ],)

                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                );
                              }),
                     ),

                      )

                    ],
                  )
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
  _getLocation() async {
    LocationResult result = await Navigator.of(context).push(MaterialPageRoute(
        builder: (context) => PlacePicker(
          "AIzaSyCqQW9tN814NYD_MdsLIb35HRY65hHomco",
        )));
    print("checking adderss detail ${result.country!.name.toString()} and ${result.locality.toString()} and ${result.country!.shortName.toString()} ");
    setState(() {
      addressC.text = result.formattedAddress.toString();
      cityC.text = result.locality.toString();
      stateC.text = result.administrativeAreaLevel1!.name.toString();
      countryC.text = result.country!.name.toString();
      lat = result.latLng!.latitude;
      long = result.latLng!.longitude;
      pincodeC.text = result.postalCode.toString();
    });
  }

}
