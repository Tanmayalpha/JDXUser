import 'dart:convert';

import 'package:dropdown_search/dropdown_search.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_connect/http/src/utils/utils.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:job_dekho_app/Jdx_screens/Dashbord.dart';
import 'package:place_picker/entities/location_result.dart';
import 'package:place_picker/widgets/place_picker.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../Model/MaterialCategoryModel.dart';
import '../Model/ParcelHistoryModel.dart';
import '../Model/ParcelWeightModel.dart';
import '../Model/registerparcelmodel.dart';
import '../Utils/api_path.dart';
import '../Utils/color.dart';
import 'MyProfile.dart';
import 'ParcelDetails.dart';
import 'notification_Screen.dart';

class RegistParcelScreen extends StatefulWidget {
  const RegistParcelScreen({Key? key}) : super(key: key);

  @override
  State<RegistParcelScreen> createState() => _RegistParcelScreenState();
}

class _RegistParcelScreenState extends State<RegistParcelScreen> {
  TextEditingController senderNameController = TextEditingController();
  TextEditingController senderMobileController = TextEditingController();
  TextEditingController recipientAddressCtr = TextEditingController();
  TextEditingController senderAddressCtr = TextEditingController();
  TextEditingController nameC = TextEditingController();
  TextEditingController senderfulladdressCtr = TextEditingController();
  TextEditingController recipientMobileController = TextEditingController();
  TextEditingController pincodeC = TextEditingController();
  TextEditingController cityC = TextEditingController();
  TextEditingController addressC = TextEditingController();
  TextEditingController receiverfulladdressCtr = TextEditingController();
  TextEditingController recipientNameController = TextEditingController();
  TextEditingController stateC = TextEditingController();
  TextEditingController countryC = TextEditingController();

  double lat = 0.0;
  double long = 0.0;
  // String radioButtonItem = 'ONE';
  int id = 0;

  ParcelDetailsModel? parcelDetailsModel;

  List<dynamic>  receiverList = [];
  // List<String>  selectedvalue = [];

  senParcel() async{
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? userid = prefs.getString('userid');
    print("User Id ${userid.toString()}");
    print("Register and Sender Parcel");
    var headers = {
      'Content-Type': 'application/json',
      'Cookie': 'ci_session=1b21f643064e1ac4622693b37863ecfa449561dd',
    };
    var request = http.Request('POST', Uri.parse('https://developmentalphawizz.com/JDX/api/payment/send_parcel'));
    request.body = json.encode({
      "sender_name": senderNameController.text,
      "sender_address": senderAddressCtr.text,
      "sender_phone": senderMobileController.text,
      "sender_latitude": "454",
      "sender_longitude": "54",
      "sender_fulladdress": senderfulladdressCtr.text,
      "user_id": "${userid.toString()}",
      "data_arr": receiverList.toString(),

    });
    request.headers.addAll(headers);
    http.StreamedResponse response = await request.send();
    if (response.statusCode == 200) {
      print("Working Now Here");
      var finalResult = await response.stream.bytesToString();
      final jsonResponse = ParcelDetailsModel.fromJson(json.decode(finalResult));
      print("Result here Now@@@@@@ ${finalResult.toString()}");
      setState((){
        parcelDetailsModel = jsonResponse;
      });
    }
    else {
      print(response.reasonPhrase);
    }
  }

  MaterialCategoryModel? materialCategoryModel;
  materialCategory() async {
    var headers = {
      'Cookie': 'ci_session=18b59dc18c8193fd4e5e1c025a6904983b2ca7e4'
    };
    var request = http.MultipartRequest('GET', Uri.parse('https://developmentalphawizz.com/JDX/api/Products/Category'));

    request.headers.addAll(headers);
    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      print("Material category");
      var finalResult = await response.stream.bytesToString();
      final jsonResponse = MaterialCategoryModel.fromJson(json.decode(finalResult));
      print("final Result>>>>>>> ${finalResult.toString()}");
      setState(() {
        materialCategoryModel = jsonResponse;
      });
    }
    else {
      print(response.reasonPhrase);
    }
  }

  ParcelWeightModel? parcelWeightModel;
  parcelWeight() async {
    var headers = {
      'Cookie': 'ci_session=18b59dc18c8193fd4e5e1c025a6904983b2ca7e4'
    };
    var request = http.MultipartRequest('GET',Uri.parse('${ApiPath.baseUrl}Products/getweight'));

    request.headers.addAll(headers);
    http.StreamedResponse response = await request.send();
    if (response.statusCode == 200) {

      var finalResult = await response.stream.bytesToString();
      final jsonResponse = ParcelWeightModel.fromJson(json.decode(finalResult));
      print("final Result>>>>>>> ${finalResult.toString()}");

      setState(() {
        parcelWeightModel = jsonResponse;
      });
    }
    else {
      print("Enterrrrrrrrrr");
      print(response.reasonPhrase);
    }
  }


  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Future.delayed(Duration(milliseconds: 100),(){
      return senParcel();
    });
    Future.delayed(Duration(milliseconds: 100),(){
      return materialCategory();
    });
    Future.delayed(Duration(milliseconds: 100),(){
      return parcelWeight();
    });
  }

  String? selectedValue;
  String? selectedValue1;

  @override
  Widget build(BuildContext context) {
    // Data data = materialCategoryModel!.data![0].title;
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        centerTitle: true,
        backgroundColor: primaryColor,
        leading: GestureDetector(
          onTap: (){
            Get.to(MyStatefulWidget());
          },
          child: Icon(Icons.arrow_back, color: whiteColor, size: 20),
          //Icon(Icons.arrow_back_ios, color: whiteColor, size: 22),
        ),
        title:  Text('Ragister Parcle', style: TextStyle(color: whiteColor, fontSize: 18, fontWeight: FontWeight.bold,fontFamily: 'Lora'),),
        actions: [
          Padding(
            padding:  EdgeInsets.only(right: 10),
            child: InkWell(
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context) => NotificationScreen()));
                },
                child: Icon(Icons.notifications,color: Colors.white,)),
          ),
        ],
      ),
      body:SingleChildScrollView(
        child:  parcelDetailsModel == null || parcelDetailsModel == "" ? Center(child: CircularProgressIndicator(),) :
        Container(
          child:
          Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 20,),
              ///senderdetails
              Column(
                children: const [
                  Padding(
                    padding: EdgeInsets.only(left: 30.0),
                    child: Text("Sender Details",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
                  ),
                ],
              ),
              Center(
                child: Column(
                  children: [
                    SizedBox(height: 20,),
                    Material(
                      elevation: 10,
                      borderRadius: BorderRadius.circular(10),
                      child: Container(
                        width: MediaQuery.of(context).size.width / 1.2,
                        height: 50,
                        child: TextField(
                          controller: senderNameController,
                          decoration: InputDecoration(
                            border: const OutlineInputBorder(
                                borderSide: BorderSide.none
                            ),
                            hintText: "Sender Name",
                            prefixIcon: Image.asset('assets/AuthAssets/Icon awesome-user.png', scale: 2.1, color: primaryColor,),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 20,),
                    Material(
                      elevation: 10,
                      borderRadius: BorderRadius.circular(10),
                      child: Container(
                        width: MediaQuery.of(context).size.width / 1.2,
                        height: 50,
                        child: TextField(
                          controller: senderMobileController,
                          keyboardType: TextInputType.number,
                          decoration: InputDecoration(
                            border: const OutlineInputBorder(
                                borderSide: BorderSide.none
                            ),
                            hintText: "Sender Mobile No.",
                            prefixIcon: Image.asset('assets/AuthAssets/Icon ionic-ios-call.png', scale: 2.1, color: primaryColor,),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 20,),
                    // _addressField(context),
                    Material(
                      elevation: 10,
                      borderRadius: BorderRadius.circular(10),
                      child: Container(
                        width: MediaQuery.of(context).size.width / 1.2,
                        height: 60,
                        child: TextField(
                          readOnly: true,
                          controller: addressC,
                          maxLines: 1,
                          onTap: (){
                            _getLocation();
                          },
                          textInputAction: TextInputAction.next,
                          decoration: InputDecoration(
                            border: const OutlineInputBorder(
                                borderSide: BorderSide.none
                            ),
                            hintText: "Sender Address",
                            prefixIcon: Image.asset('assets/ProfileAssets/locationIcon.png', scale: 1.5, color: primaryColor,),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 20,),
                    Material(
                      elevation: 10,
                      borderRadius: BorderRadius.circular(10),
                      child: Container(
                        width: MediaQuery.of(context).size.width / 1.2,
                        height: 80,
                        child: TextField(
                          controller: senderfulladdressCtr,
                          decoration: InputDecoration(
                            border: const OutlineInputBorder(
                              borderSide: BorderSide.none,
                            ),
                            hintText: "flat number,floor,building name,etc",
                            prefixIcon: Image.asset('assets/ProfileAssets/locationIcon.png', scale: 1.7, color: primaryColor,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],),
              ),
              ///recipentdetails
              SizedBox(height: 20,),
              Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 30.0),
                    child: Text("Recipient Details",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
                  ),
                ],
              ),
              Center(
                child: Column(
                  children: [
                    SizedBox(height: 20,),
                    Material(
                      elevation: 10,
                      borderRadius: BorderRadius.circular(10),
                      child: Container(
                        width: MediaQuery.of(context).size.width / 1.2,
                        height: 50,
                        child: TextField(
                          controller: recipientNameController,
                          decoration: InputDecoration(
                            border: const OutlineInputBorder(
                                borderSide: BorderSide.none
                            ),
                            hintText: "Recipient Name",
                            prefixIcon: Image.asset('assets/AuthAssets/Icon awesome-user.png', scale: 2.1, color: primaryColor,),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 20,),
                    Material(
                      elevation: 10,
                      borderRadius: BorderRadius.circular(10),
                      child: Container(
                        width: MediaQuery.of(context).size.width / 1.2,
                        height: 50,
                        child: TextField(
                          controller: recipientMobileController,
                          decoration: InputDecoration(
                            border: const OutlineInputBorder(
                                borderSide: BorderSide.none,
                            ),
                            hintText: "Recipient Mobile No.",
                            prefixIcon: Image.asset('assets/AuthAssets/Icon ionic-ios-call.png', scale: 2.1, color: primaryColor,),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 20,),
                    // _addressField(context),
                    Material(
                      elevation: 10,
                      borderRadius: BorderRadius.circular(10),
                      child: Container(
                        width: MediaQuery.of(context).size.width / 1.2,
                        height: 60,
                        child: TextField(
                          readOnly: true,
                          controller:addressC,

                          maxLines: 1,
                          onTap: (){
                            _getLocation();
                          },
                          textInputAction: TextInputAction.next,
                          decoration: InputDecoration(
                            border: const OutlineInputBorder(
                                borderSide: BorderSide.none
                            ),
                            hintText: "Recipient Address",
                            prefixIcon: Image.asset('assets/ProfileAssets/locationIcon.png', scale: 1.5, color: primaryColor,),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 20,),

                    Material(
                      elevation: 10,
                      borderRadius: BorderRadius.circular(10),
                      child: Container(
                        width: MediaQuery.of(context).size.width / 1.2,
                        height: 80,
                        child:  TextField(
                          controller: receiverfulladdressCtr,
                          decoration: InputDecoration(
                            border: OutlineInputBorder(
                              borderSide: BorderSide.none,
                            ),
                            hintText: "flat number,floor,building name,etc",
                            prefixIcon: Image.asset('assets/ProfileAssets/locationIcon.png', scale: 1.7, color: primaryColor,
                            ),
                          )))),
                  ],),
              ),
              ///parceldetails
              SizedBox(height: 20,),
              Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 30.0),
                    child: Text("Parcel Details ",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
                  ),
                ],
              ),
              Center(
                child: Column(
                  children: [
                    SizedBox(height: 20,),
                    Material(
                      elevation: 10,
                      borderRadius: BorderRadius.circular(10),
                      child: Container(
                        height: 55,
                        width: MediaQuery.of(context).size.width/ 1.2,
                        child:   DropdownButton(
                          underline: Container(),
                          value: selectedValue,
                          icon: Padding(
                            padding: const EdgeInsets.only(left: 50),
                            child: const Icon(Icons.keyboard_arrow_down, color: Color(0xFFBF2331)),
                          ),
                          items: materialCategoryModel!.data!.map((items) {
                            return DropdownMenuItem(
                              value: items.id.toString(),
                              child: Text(items.title.toString()
                              ),
                            );
                          }).toList(),
                          onChanged: ( newValue) {
                            setState(() {
                              selectedValue = newValue!;
                            });
                          },
                        ),
                      ),
                    ),
                    SizedBox(height: 20,),
                    Material(
                      elevation: 10,
                      borderRadius: BorderRadius.circular(10),
                      child: Container(
                        height: 55,
                        width: MediaQuery.of(context).size.width/ 1.2,
                        child:   DropdownButton(
                          underline: Container(),
                          value: selectedValue1,
                          icon: Padding(
                            padding: const EdgeInsets.only(left: 160),
                            child: const Icon(Icons.keyboard_arrow_down, color: Color(0xFFBF2331)),
                          ),
                          items: parcelWeightModel!.data!.map((items) {
                            return DropdownMenuItem(
                              value: items.id.toString(),
                              child: Text(items.weightTo.toString()),
                            );
                          }).toList(),
                          onChanged: ( newValue) {
                            setState(() {
                              selectedValue1 = newValue!;
                            });
                          },
                        ),
                      ),
                    ),
                    SizedBox(height: 15,),
                    Container(
                      // color: Colors.cyan,
                      // height: 100,
                      child: ListView.builder(
                        scrollDirection: Axis.vertical,
                        physics: NeverScrollableScrollPhysics(),
                        shrinkWrap: true,
                        itemCount: receiverList.length,
                          itemBuilder: (context, index) {
                          return Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Card(
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(15.0),
                              ),
                              elevation: 10,
                              color: Theme.of(context).colorScheme.surfaceVariant,
                              child: SizedBox(
                                width: MediaQuery.of(context).size.width/ 1.1,
                                height: 200,
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Column(

                                    children: [
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                        children: [
                                          Column(
                                            // mainAxisAlignment: MainAxisAlignment.start,
                                            // crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Padding(
                                                padding: const EdgeInsets.only(right: 38.0),
                                                child: const Text("Recipient Name", style: TextStyle(fontSize: 13, color: Color(0xFFBF2331))),
                                              ),
                                              Text("${receiverList[index]['recptName']}"),
                                            ],
                                          ),
                                          Padding(
                                            padding: const EdgeInsets.only(left: 48.0),
                                            child: InkWell(
                                                onTap: (){
                                                  showDialog(
                                                      context: context,
                                                      barrierDismissible: false,
                                                      builder: (BuildContext context) {
                                                        return AlertDialog(
                                                          title: Text("Delete Account"),
                                                          content: Text("Are you sure you want to delete the order"),
                                                          actions: <Widget>[
                                                            ElevatedButton(
                                                              style: ElevatedButton.styleFrom(
                                                                primary: Color(0xFFBF2331),
                                                              ),
                                                              child: Text("YES"),
                                                              onPressed: () {
                                                                // deleteAccount();
                                                                // SystemNavigator.pop();
                                                                // Navigator.pop(context, MaterialPageRoute(builder: (context) => Login()));
                                                              },
                                                            ),
                                                            ElevatedButton(
                                                              style: ElevatedButton.styleFrom(
                                                                // primary: colors.primary
                                                              ),
                                                              child: Text("NO"),
                                                              onPressed: () {
                                                                Navigator.of(context).pop();
                                                              },
                                                            )
                                                          ],
                                                        );
                                                      }
                                                  );
                                                  Column(
                                                    children: [
                                                      Padding(
                                                        padding: const EdgeInsets.only(left: 10),
                                                        child: Container(
                                                          height: 45,
                                                          width: MediaQuery.of(context).size.width/1.5,
                                                          decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), color: Color(0xFFBF2331)),
                                                          child:
                                                          const Center(
                                                            child: Text("Delete Account", style: TextStyle(fontSize: 15, fontWeight: FontWeight.w500),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  );
                                                },
                                                child: Icon(Icons.delete, color: Color(0xFFBF2331))
                                            ),
                                          ),
                                          InkWell(
                                              onTap: (){

                                              },
                                              child: Icon(Icons.edit, color: Color(0xFFBF2331))),
                                        ],
                                      ),
                                      SizedBox(height: 6,),
                                      Padding(
                                        padding: const EdgeInsets.only(left: 10),
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          children: [
                                            Column(
                                              children: [
                                                Text("Mobile No", style: TextStyle(fontSize: 13, color: Color(0xFFBF2331)),),
                                                Text("${receiverList[index]['recptmobile']}"),
                                              ],
                                            ),
                                            Padding(
                                              padding: const EdgeInsets.only(right: 7),
                                              child: Column(
                                                children: [
                                                  Text("Material category", style: TextStyle(fontSize: 13, color: Color(0xFFBF2331)),),
                                                  Text("${receiverList[index]['materialcategory']}"),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      SizedBox(height: 6,),
                                      Padding(
                                        padding: const EdgeInsets.only(left: 10),
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          children: [
                                            Column(
                                              children: [
                                                Text("Recipient Address", style: TextStyle(fontSize: 13, color: Color(0xFFBF2331)),),
                                                Text("${receiverList[index]['recptaddress']}"),
                                              ],
                                            ),
                                            Padding(
                                              padding: const EdgeInsets.only(right: 7),
                                              child: Column(
                                                children: [
                                                  Text("Parcel weight", style: TextStyle(fontSize: 13, color: Color(0xFFBF2331)),),
                                                  Text("${receiverList[index]['parcelweight']}."),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      SizedBox(height: 6,),
                                      Padding(
                                        padding: const EdgeInsets.only(left: 10),
                                        child: Row(
                                          children: [
                                            Column(
                                              children: [
                                                Text("Receipient Flat Number", style: TextStyle(fontSize: 13, color: Color(0xFFBF2331)),),
                                                Text("${receiverList[index]['receptfulladdress']}"),
                                              ],
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          );
                          }
                      ),
                    ),
                    SizedBox(height: 15,),
                    SizedBox(height: 50,),
                    InkWell(
                      onTap: (){

                       setState(() {
                         receiverList.add({
                           "recptName": recipientNameController.text,
                           "recptmobile": recipientMobileController.text,
                           "recptaddress": recipientAddressCtr.text,
                           "receptfulladdress": receiverfulladdressCtr.text,
                           "materialcategory": selectedValue.toString(),
                           "parcelweight": selectedValue1.toString(),
                         });
                       });
                       print("checking hereeeee ${receiverList.length} and ${receiverList}");
                       // Navigator.pop(context);
                       // setState(() {});
                       //
                       // int materialValue = 0;
                       // int parcelValue = 0;
                       // int recnameValue = 0;
                       // int recaddValue = 0;
                       // int recmobValue = 0;
                       // int recfulladdValue = 0;
                       //
                       // setState(() {
                       // });
                       // for(var i=0; i<receiverList.length; i++){
                       //   materialValue = int.parse(receiverList[i][''].toString());
                       //   print("Material Valueee ${materialValue}");
                       //   setState(() {});
                       // }
                       // setState(() {});
                       //
                       // for(var i=0; i<receiverList.length; i++){
                       //   parcelValue = int.parse(receiverList[i][''].toString());
                       //   print("Parcel Details Value ${parcelValue}");
                       //   setState(() {});
                       // }
                       // setState(() {});
                       //
                       // for(var i=0; i<receiverList.length; i++){
                       //   recnameValue = int.parse(receiverList[i][''].toString());
                       //   print("Parcel Details Value ${recnameValue}");
                       //   setState(() {});
                       // }
                       // setState(() {});
                       //
                       // for(var i=0; i<receiverList.length; i++){
                       //   recaddValue = int.parse(receiverList[i][''].toString());
                       //   print("Parcel Details Value ${recaddValue}");
                       //   setState(() {});
                       // }
                       // setState(() {});
                       //
                       // for(var i=0; i<receiverList.length; i++){
                       //   recfulladdValue = int.parse(receiverList[i][''].toString());
                       //   print("Parcel Details Value ${recfulladdValue}");
                       //   setState(() {});
                       // }
                       // setState(() {});
                       //
                       // for(var i=0; i<receiverList.length; i++){
                       //   recmobValue = int.parse(receiverList[i][''].toString());
                       //   print("Parcel Details Value ${recmobValue}");
                       //   setState(() {});
                       // }
                       recipientNameController.clear();
                       recipientAddressCtr.clear();
                       recipientMobileController.clear();
                       receiverfulladdressCtr.clear();
                      //  Get.to(MyStatefulWidget());
                      },
                      child: Container(
                        height: 45,
                        width: MediaQuery.of(context).size.width/1.2,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(30),
                            color: Secondry
                        ),
                        child: Text("Add More",style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold,fontSize: 14,),),
                      ),
                    ),
                    const SizedBox(height: 20,),
                    InkWell(
                      onTap: (){
                        // parcelDetails();
                        // Get.to(ParcelDetails());
                      },
                      child: Container(
                        height: 45,
                        width: MediaQuery.of(context).size.width/1.2,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(30),
                            color: Secondry
                        ),
                        child: Text("save",style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold,fontSize: 14,),),
                      )),
                  ],
                )),
              // Center(
              //   child: DropdownSearch<String>(
              //     popupProps: PopupProps.menu(
              //       showSelectedItems: true,
              //       showSearchBox: true,
              //       disabledItemFn: (String s) => s.startsWith('I'),
              //     ),
              //
              //     items: ["Brazil", "Italia (Disabled)", "Tunisia", 'Canada,'],
              //     dropdownDecoratorProps: DropDownDecoratorProps(
              //       dropdownSearchDecoration: InputDecoration(
              //         labelText: "Menu mode",
              //         hintText: "country in menu mode",
              //       ),
              //     ),
              //     onChanged: print,
              //     selectedItem: "Brazil",
              //   ),
              // ),
              //
              // DropdownSearch<String>.multiSelection(
              //   items: ["Brazil", "Italia (Disabled)", "Tunisia", 'Canada'],
              //   popupProps: PopupPropsMultiSelection.menu(
              //     showSelectedItems: true,
              //     disabledItemFn: (String s) => s.startsWith('I'),
              //   ),
              //   onChanged: print,
              //   selectedItems: ["Brazil"],
              // )
            ],
          ),
        ),
      ),
    );
  }


  // Widget recipietCart(int index) {
  //   return
  //     Center(
  //     child: Card(
  //       elevation: 0,
  //       color: Theme.of(context).colorScheme.surfaceVariant,
  //       child: SizedBox(
  //         width: MediaQuery.of(context).size.width/ 1.2,
  //         height: 80,
  //         child: Row(
  //           mainAxisAlignment: MainAxisAlignment.spaceBetween,
  //           children: [
  //           Text("Recipient Name"),
  //           Icon(Icons.delete),
  //           Icon(Icons.edit),
  //         ],),
  //       ),
  //     ),
  //   );
  // }

  _getLocation() async {
    LocationResult result = await Navigator.of(context).push(MaterialPageRoute(
        builder: (context) => PlacePicker(
          "AIzaSyCqQW9tN814NYD_MdsLIb35HRY65hHomco",
        )));
    print("checking adderss detail ${result.country!.name.toString()} and ${result.locality.toString()} and ${result.country!.shortName.toString()} ");
    setState(() {
      addressC.text = result.formattedAddress.toString();
      cityC.text = result.locality.toString();
      stateC.text = result.administrativeAreaLevel1!.name.toString();
      countryC.text = result.country!.name.toString();
      lat = result.latLng!.latitude;
      long = result.latLng!.longitude;
      pincodeC.text = result.postalCode.toString();
    });
  }

}
