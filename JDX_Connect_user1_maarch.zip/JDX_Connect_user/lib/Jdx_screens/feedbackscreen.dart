import 'package:dropdown_search/dropdown_search.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

import '../Utils/color.dart';
import 'MyProfile.dart';
import 'notification_Screen.dart';

class FeedbackScreen extends StatefulWidget {
  const FeedbackScreen({Key? key}) : super(key: key);

  @override
  State<FeedbackScreen> createState() => _FeedbackScreenState();
}

class _FeedbackScreenState extends State<FeedbackScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: GestureDetector(
          onTap: (){
            Get.to(DrawerScreen());
          },
          child: Icon(Icons.arrow_back),
          // child: Image.asset('assets/ProfileAssets/menu_icon.png', scale: 1.6,),
        ),
        elevation: 0,
        backgroundColor: primaryColor,
        title: Text("Driver Feedback",style: TextStyle(fontFamily: 'Lora'),),
        centerTitle: true,
        actions: [
          Padding(
            padding:  EdgeInsets.only(right: 10),
            child: InkWell(
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context) => NotificationScreen()));
                },
                child: Icon(Icons.notifications,color: Colors.white,)),
          )
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Column(
                children: [
                  SizedBox(height: 20,),
                  Material(
                    elevation: 10,
                    borderRadius: BorderRadius.circular(10),
                    child: Container(

                      width: MediaQuery.of(context).size.width / 1.2,
                      height: 40,
                      child: DropdownSearch<String>(
                        //mode of dropdown
                        mode: Mode.DIALOG,
                        //to show search box
                        // showSearchBox: true,
                        showSelectedItem: true,

                        //list of dropdown items
                        items: [
                          AutofillHints.orderid,
                          "  192",
                          "  10",
                          " 100 ",
                          " 502 ",
                          " 201 ",
                          " 100 ",

                        ],
                        label: "order ID ",

                        onChanged: print,
                        //show selected item
                        selectedItem: "160",
                      ),
                    ),
                  ),
                  const SizedBox(height: 30,),

                ],),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text("Parcel ID"),

            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text("Driver Name"),
            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                RatingBar.builder(
                  initialRating: 3,
                  minRating: 1,
                  direction: Axis.horizontal,
                  allowHalfRating: true,
                  itemCount: 5,
                  itemPadding: EdgeInsets.symmetric(horizontal: 4.0),
                  itemBuilder: (context, _) => Icon(
                    Icons.star,
                    color: Colors.amber,
                  ),
                  onRatingUpdate: (rating) {
                    print(rating);
                  },),
                Padding(
                  padding: const EdgeInsets.only(left: 15.0),
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: splashcolor,
                    ),

                    width: MediaQuery.of(context).size.width/1.1,
                    height: 150,
                    child: TextField(
                      decoration: InputDecoration(
                        border: OutlineInputBorder(
                          borderSide: BorderSide.none,
                        ),
                        hintText: "Add Review",
                      ),),),
                ),
                SizedBox(height: 20,),


                InkWell(
                  onTap: (){
                  },
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: primaryColor,
                    ),
                    height: 40,
                    width: MediaQuery.of(context).size.width/2.5,
                    child: Center(child: Text("Add Review",style: TextStyle(color: whiteColor,fontSize: 15),)),
                  ),
                ),

              ],
            ),





          ],
        ),
      ),


    );
  }
}
