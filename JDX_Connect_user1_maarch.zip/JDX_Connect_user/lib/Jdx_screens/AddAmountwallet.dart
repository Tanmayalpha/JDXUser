import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

import '../Utils/color.dart';
import 'notification_Screen.dart';

class AddAmount extends StatefulWidget {
  const AddAmount({Key? key}) : super(key: key);

  @override
  State<AddAmount> createState() => _AddAmountState();
}

class _AddAmountState extends State<AddAmount> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        centerTitle: true,
        backgroundColor: primaryColor,
        leading: GestureDetector(
          onTap: (){
            Navigator.pop(context);
          },
          child: Icon(Icons.arrow_back_ios, color: whiteColor, size: 20),
          //Icon(Icons.arrow_back_ios, color: whiteColor, size: 22),
        ),
        title:  Text('Add Amount', style: TextStyle(color: whiteColor, fontSize: 18, fontWeight: FontWeight.bold),),
        actions: [
          Padding(
            padding:  EdgeInsets.only(right: 10),
            child: InkWell(
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context) => NotificationScreen()));
                },
                child: Icon(Icons.notifications,color: Colors.white,)),
          )
        ],
      ),

      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(

          children: [

            Center(child: Text("Add money to wallet",style: TextStyle(fontSize: 20,fontWeight: FontWeight.w500),)),
            Text("Available Balance",style: TextStyle(fontSize: 20,fontWeight: FontWeight.w500),),
            Text("₹ 100",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),),
            SizedBox(height: 20,),

            Material(
              elevation: 10,
              borderRadius: BorderRadius.circular(10),
              child: Container(
                width: MediaQuery.of(context).size.width / 1.2,
                height: 50,
                child: TextField(
                  decoration: InputDecoration(
                    border: const OutlineInputBorder(
                        borderSide: BorderSide.none
                    ),
                    hintText: "Amount",
                  ),
                ),
              ),
            ),
            SizedBox(height: 20,),
            InkWell(
              onTap: (){
                // Get.to(AddAmount());
              },
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: primaryColor,
                ),
                height: 40,
                width: MediaQuery.of(context).size.width/2.5,
                child: Center(child: Text("Proceed",style: TextStyle(color: whiteColor,fontSize: 15),)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
