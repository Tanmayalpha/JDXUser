import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

import '../Utils/color.dart';
import 'MyProfile.dart';
import 'notification_Screen.dart';

class ParcelDetails extends StatefulWidget {
  const ParcelDetails({Key? key}) : super(key: key);

  @override
  State<ParcelDetails> createState() => _ParcelDetailsState();
}

class _ParcelDetailsState extends State<ParcelDetails> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: GestureDetector(
          onTap: (){
            Get.to(DrawerScreen());
          },
          child: Icon(Icons.arrow_back),
          // child: Image.asset('assets/ProfileAssets/menu_icon.png', scale: 1.6,),
        ),
        elevation: 0,
        backgroundColor: primaryColor,
        title: Text("Parcel Details",style: TextStyle(fontFamily: 'Lora'),),
        centerTitle: true,
        actions: [
          Padding(
            padding:  EdgeInsets.only(right: 10),
            child: InkWell(
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context) => NotificationScreen()));
                },
                child: Icon(Icons.notifications,color: Colors.white,)
            ),
          ),
        ],
      ),
      body: Column(
        children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
          child: Card(
            shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(25.0),
             ),
            elevation: 10,
               color: Theme.of(context).colorScheme.surfaceVariant,
            child:Center(
              child: SizedBox(
                width: MediaQuery.of(context).size.width/ 1.2,
                height: 200,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            children: [
                              Text("Sender Name"),
                              Text("New"),
                            ],
                          ),
                          Column(
                            children: [
                              Text("Sender Mobile No."),
                              Text("980897890"),
                            ],
                          ),
                      ],
                      ),
                      SizedBox(height: 10,),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            children: [
                              Text("Total Ammount"),
                              Text("2000"),
                            ],
                          ),
                          Column(
                            children: [
                              Text("Sender Address"),
                              Text("Indore"),
                            ],
                          ),
                        ],
                      ),
                      SizedBox(height: 14,),
                      Row(
                        // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            children: [
                              Text("Flat and floor no."),
                              Text("123 Indore"),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            )
          ),
        ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
            child: Card(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(25.0),
                ),
                elevation: 10,
                color: Theme.of(context).colorScheme.surfaceVariant,
                child:Center(
                  child: SizedBox(
                    width: MediaQuery.of(context).size.width/ 1.2,
                    height: 200,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
                      child: Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Column(
                                children: [
                                  Text("Parcel Id"),
                                  Text("New"),
                                ],
                              ),
                              Column(
                                children: [
                                  Text("Order Date"),
                                  Text("980897890"),
                                ],
                              ),
                            ],
                          ),
                          SizedBox(height: 10,),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Column(
                                children: [
                                  Text("Recipient Name"),
                                  Text("New Receiver"),
                                ],
                              ),
                              Column(
                                children: [
                                  Text("Recipient Mobile No."),
                                  Text("9807970800"),
                                ],
                              ),
                            ],
                          ),
                          SizedBox(height: 14,),
                          Row(
                            // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Column(
                                children: [
                                  Text("Recipient Address"),
                                  Text("123 Indoreee"),
                                ],
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                )
            ),
          ),
      ],
      ),
    );
  }
}
