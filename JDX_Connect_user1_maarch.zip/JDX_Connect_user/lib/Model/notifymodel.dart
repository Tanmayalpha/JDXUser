/// status : true
/// data : [{"id":"3126","user_id":"4","notification":"Payment Successfully","invoice_id":"303","order_id":"0","status":"1","device_id":"","date":"19/02/2022","time":"13:20:50","watched":"1","types":"0"},{"id":"3142","user_id":"4","notification":"Payment Successfully","invoice_id":"304","order_id":"0","status":"1","device_id":"","date":"19/02/2022","time":"13:34:46","watched":"1","types":"0"},{"id":"3158","user_id":"4","notification":"Payment Successfully","invoice_id":"308","order_id":"0","status":"1","device_id":"","date":"19/02/2022","time":"14:34:27","watched":"1","types":"0"},{"id":"3174","user_id":"4","notification":"Payment Successfully","invoice_id":"309","order_id":"0","status":"1","device_id":"","date":"19/02/2022","time":"14:39:04","watched":"1","types":"0"},{"id":"3193","user_id":"4","notification":"Payment Successfully","invoice_id":"311","order_id":"0","status":"1","device_id":"","date":"19/02/2022","time":"14:46:31","watched":"1","types":"0"},{"id":"3204","user_id":"4","notification":"Payment Successfully","invoice_id":"311","order_id":"0","status":"1","device_id":"","date":"19/02/2022","time":"14:46:32","watched":"1","types":"0"},{"id":"3221","user_id":"4","notification":"Payment Successfully","invoice_id":"312","order_id":"0","status":"1","device_id":"","date":"19/02/2022","time":"14:48:04","watched":"1","types":"0"},{"id":"3244","user_id":"4","notification":"Payment Successfully","invoice_id":"313","order_id":"0","status":"1","device_id":"","date":"19/02/2022","time":"14:52:50","watched":"1","types":"0"},{"id":"3253","user_id":"4","notification":"Payment Successfully","invoice_id":"313","order_id":"0","status":"1","device_id":"","date":"19/02/2022","time":"14:52:51","watched":"1","types":"0"},{"id":"3254","user_id":"4","notification":"Payment Successfully","invoice_id":"314","order_id":"0","status":"1","device_id":"","date":"19/02/2022","time":"15:01:31","watched":"1","types":"0"},{"id":"3273","user_id":"4","notification":"Payment Successfully","invoice_id":"316","order_id":"0","status":"1","device_id":"","date":"19/02/2022","time":"16:31:12","watched":"1","types":"0"},{"id":"3296","user_id":"4","notification":"Payment Successfully","invoice_id":"316","order_id":"0","status":"1","device_id":"","date":"19/02/2022","time":"16:31:14","watched":"1","types":"0"},{"id":"3302","user_id":"4","notification":"Payment Successfully","invoice_id":"316","order_id":"0","status":"1","device_id":"","date":"19/02/2022","time":"16:31:15","watched":"1","types":"0"},{"id":"3318","user_id":"4","notification":"Payment Successfully","invoice_id":"317","order_id":"0","status":"1","device_id":"","date":"19/02/2022","time":"16:33:38","watched":"1","types":"0"},{"id":"3334","user_id":"4","notification":"Payment Successfully","invoice_id":"317","order_id":"0","status":"1","device_id":"","date":"19/02/2022","time":"16:33:40","watched":"1","types":"0"},{"id":"3335","user_id":"4","notification":"Payment Successfully","invoice_id":"273","order_id":"0","status":"1","device_id":"","date":"19/02/2022","time":"16:43:14","watched":"1","types":"0"},{"id":"3336","user_id":"4","notification":"Payment Successfully","invoice_id":"274","order_id":"0","status":"1","device_id":"","date":"19/02/2022","time":"16:43:14","watched":"1","types":"0"},{"id":"3337","user_id":"4","notification":"Payment Successfully","invoice_id":"275","order_id":"0","status":"1","device_id":"","date":"19/02/2022","time":"16:43:14","watched":"1","types":"0"},{"id":"3338","user_id":"4","notification":"Payment Successfully","invoice_id":"273","order_id":"0","status":"1","device_id":"","date":"19/02/2022","time":"16:50:33","watched":"1","types":"0"},{"id":"3339","user_id":"4","notification":"Payment Successfully","invoice_id":"274","order_id":"0","status":"1","device_id":"","date":"19/02/2022","time":"16:50:33","watched":"1","types":"0"},{"id":"3340","user_id":"4","notification":"Payment Successfully","invoice_id":"275","order_id":"0","status":"1","device_id":"","date":"19/02/2022","time":"16:50:33","watched":"1","types":"0"},{"id":"3341","user_id":"4","notification":"Payment Successfully","invoice_id":"273","order_id":"0","status":"1","device_id":"","date":"19/02/2022","time":"16:56:47","watched":"1","types":"0"},{"id":"3342","user_id":"4","notification":"Payment Successfully","invoice_id":"274","order_id":"0","status":"1","device_id":"","date":"19/02/2022","time":"16:56:47","watched":"1","types":"0"},{"id":"3343","user_id":"4","notification":"Payment Successfully","invoice_id":"275","order_id":"0","status":"1","device_id":"","date":"19/02/2022","time":"16:56:47","watched":"1","types":"0"},{"id":"3344","user_id":"4","notification":"Payment Successfully","invoice_id":"273","order_id":"0","status":"1","device_id":"","date":"19/02/2022","time":"16:58:52","watched":"1","types":"0"},{"id":"3345","user_id":"4","notification":"Payment Successfully","invoice_id":"274","order_id":"0","status":"1","device_id":"","date":"19/02/2022","time":"16:58:52","watched":"1","types":"0"},{"id":"3346","user_id":"4","notification":"Payment Successfully","invoice_id":"275","order_id":"0","status":"1","device_id":"","date":"19/02/2022","time":"16:58:52","watched":"1","types":"0"},{"id":"3347","user_id":"4","notification":"Payment Successfully","invoice_id":"273","order_id":"0","status":"1","device_id":"","date":"19/02/2022","time":"17:00:47","watched":"1","types":"0"},{"id":"3348","user_id":"4","notification":"Payment Successfully","invoice_id":"274","order_id":"0","status":"1","device_id":"","date":"19/02/2022","time":"17:00:47","watched":"1","types":"0"},{"id":"3349","user_id":"4","notification":"Payment Successfully","invoice_id":"275","order_id":"0","status":"1","device_id":"","date":"19/02/2022","time":"17:00:47","watched":"1","types":"0"},{"id":"3350","user_id":"4","notification":"Payment Successfully","invoice_id":"273","order_id":"0","status":"1","device_id":"","date":"19/02/2022","time":"17:01:36","watched":"1","types":"0"},{"id":"3351","user_id":"4","notification":"Payment Successfully","invoice_id":"274","order_id":"0","status":"1","device_id":"","date":"19/02/2022","time":"17:01:36","watched":"1","types":"0"},{"id":"3352","user_id":"4","notification":"Payment Successfully","invoice_id":"275","order_id":"0","status":"1","device_id":"","date":"19/02/2022","time":"17:01:36","watched":"1","types":"0"},{"id":"3353","user_id":"4","notification":"Payment Successfully","invoice_id":"273","order_id":"0","status":"1","device_id":"","date":"19/02/2022","time":"17:02:56","watched":"1","types":"0"},{"id":"3354","user_id":"4","notification":"Payment Successfully","invoice_id":"274","order_id":"0","status":"1","device_id":"","date":"19/02/2022","time":"17:02:56","watched":"1","types":"0"},{"id":"3355","user_id":"4","notification":"Payment Successfully","invoice_id":"275","order_id":"0","status":"1","device_id":"","date":"19/02/2022","time":"17:02:56","watched":"1","types":"0"},{"id":"3357","user_id":"4","notification":"Payment Successfully","invoice_id":"318","order_id":"0","status":"1","device_id":"","date":"19/02/2022","time":"17:09:34","watched":"1","types":"0"},{"id":"3373","user_id":"4","notification":"Payment Successfully","invoice_id":"299","order_id":"0","status":"1","device_id":"","date":"19/02/2022","time":"17:13:13","watched":"1","types":"0"},{"id":"3550","user_id":"4","notification":"Payment Successfully","invoice_id":"273","order_id":"0","status":"1","device_id":"","date":"19/02/2022","time":"18:13:13","watched":"1","types":"0"},{"id":"3551","user_id":"4","notification":"Payment Successfully","invoice_id":"274","order_id":"0","status":"1","device_id":"","date":"19/02/2022","time":"18:13:13","watched":"1","types":"0"},{"id":"3552","user_id":"4","notification":"Payment Successfully","invoice_id":"275","order_id":"0","status":"1","device_id":"","date":"19/02/2022","time":"18:13:13","watched":"1","types":"0"},{"id":"3553","user_id":"4","notification":"Payment Successfully","invoice_id":"273","order_id":"0","status":"1","device_id":"","date":"19/02/2022","time":"18:17:12","watched":"1","types":"0"},{"id":"3554","user_id":"4","notification":"Payment Successfully","invoice_id":"274","order_id":"0","status":"1","device_id":"","date":"19/02/2022","time":"18:17:12","watched":"1","types":"0"},{"id":"3555","user_id":"4","notification":"Payment Successfully","invoice_id":"275","order_id":"0","status":"1","device_id":"","date":"19/02/2022","time":"18:17:12","watched":"1","types":"0"},{"id":"3596","user_id":"4","notification":"Your Parcel Id 16462068111 confirmed successfully. Thank you for being with us","invoice_id":"363","order_id":"0","status":"1","device_id":"","date":"03/03/2022","time":"13:12:02","watched":"1","types":"0"},{"id":"3598","user_id":"4","notification":"Your booking request accepted successfully","invoice_id":"","order_id":"0","status":"0","device_id":"","date":"2022-03-03 13:18:23","time":"","watched":"1","types":"3"},{"id":"3599","user_id":"4","notification":"Your booking request accepted successfully","invoice_id":"","order_id":"0","status":"0","device_id":"","date":"2022-03-03 13:22:11","time":"","watched":"1","types":"3"},{"id":"3600","user_id":"4","notification":"Your booking request accepted successfully","invoice_id":"","order_id":"0","status":"0","device_id":"","date":"2022-03-03 13:27:00","time":"","watched":"1","types":"3"},{"id":"3601","user_id":"4","notification":"Your Parcel Id 16462060311 confirmed successfully. Thank you for being with us","invoice_id":"362","order_id":"0","status":"1","device_id":"","date":"03/03/2022","time":"15:52:24","watched":"1","types":"0"},{"id":"3602","user_id":"4","notification":"Your Parcel Id 16462060311 confirmed successfully. Thank you for being with us","invoice_id":"362","order_id":"0","status":"1","device_id":"","date":"03/03/2022","time":"15:52:45","watched":"1","types":"0"},{"id":"3603","user_id":"4","notification":"Your Parcel Id 16462059741 confirmed successfully. Thank you for being with us","invoice_id":"361","order_id":"0","status":"1","device_id":"","date":"03/03/2022","time":"15:53:17","watched":"1","types":"0"},{"id":"3605","user_id":"4","notification":"Your Parcel Id 16462059741 confirmed successfully. Thank you for being with us","invoice_id":"361","order_id":"0","status":"1","device_id":"","date":"03/03/2022","time":"15:54:01","watched":"1","types":"0"},{"id":"3608","user_id":"4","notification":"Your booking request accepted successfully","invoice_id":"","order_id":"0","status":"0","device_id":"","date":"2022-03-03 15:55:16","time":"","watched":"1","types":"3"},{"id":"3613","user_id":"4","notification":"Your booking request accepted successfully","invoice_id":"","order_id":"0","status":"0","device_id":"","date":"2022-03-03 16:22:06","time":"","watched":"1","types":"3"},{"id":"3618","user_id":"4","notification":"Your Parcel Id 16462068111 confirmed successfully. Thank you for being with us","invoice_id":"363","order_id":"0","status":"1","device_id":"","date":"29/03/2022","time":"11:11:36","watched":"1","types":"0"},{"id":"3619","user_id":"4","notification":"Your Parcel Id 16462060311 confirmed successfully. Thank you for being with us","invoice_id":"362","order_id":"0","status":"1","device_id":"","date":"29/03/2022","time":"11:11:51","watched":"1","types":"0"},{"id":"3622","user_id":"4","notification":"Your parcel Id 16462059741 Delivered successfully.Thank you for being with us","invoice_id":"360","order_id":"0","status":"1","device_id":"","date":"04/04/2022","time":"18:22:38","watched":"1","types":"0"},{"id":"3652","user_id":"4","notification":"Payment Successfully","invoice_id":"366","order_id":"0","status":"1","device_id":"","date":"25/05/2022","time":"17:05:48","watched":"1","types":"0"},{"id":"3673","user_id":"4","notification":"Payment Successfully","invoice_id":"366","order_id":"0","status":"1","device_id":"","date":"25/05/2022","time":"17:05:49","watched":"1","types":"0"},{"id":"3680","user_id":"4","notification":"Payment Successfully","invoice_id":"366","order_id":"0","status":"1","device_id":"","date":"25/05/2022","time":"17:05:50","watched":"1","types":"0"},{"id":"3681","user_id":"4","notification":"Your Parcel Id 16534785331 confirmed successfully. Thank you for being with us","invoice_id":"366","order_id":"0","status":"1","device_id":"","date":"25/05/2022","time":"17:06:20","watched":"1","types":"0"},{"id":"3683","user_id":"4","notification":"Payment Successfully","invoice_id":"367","order_id":"0","status":"1","device_id":"","date":"06/06/2022","time":"11:32:45","watched":"1","types":"0"},{"id":"3684","user_id":"4","notification":"Payment Successfully","invoice_id":"368","order_id":"0","status":"1","device_id":"","date":"06/06/2022","time":"11:38:10","watched":"1","types":"0"},{"id":"3685","user_id":"4","notification":"Payment Successfully","invoice_id":"369","order_id":"0","status":"1","device_id":"","date":"06/06/2022","time":"11:38:10","watched":"1","types":"0"},{"id":"3686","user_id":"4","notification":"Payment Successfully","invoice_id":"370","order_id":"0","status":"1","device_id":"","date":"06/06/2022","time":"16:04:53","watched":"1","types":"0"},{"id":"3687","user_id":"4","notification":"Payment Successfully","invoice_id":"371","order_id":"0","status":"1","device_id":"","date":"06/06/2022","time":"16:04:53","watched":"1","types":"0"},{"id":"3688","user_id":"4","notification":"Payment Successfully","invoice_id":"372","order_id":"0","status":"1","device_id":"","date":"07/06/2022","time":"13:36:36","watched":"1","types":"0"},{"id":"3689","user_id":"4","notification":"Payment Successfully","invoice_id":"373","order_id":"0","status":"1","device_id":"","date":"07/06/2022","time":"13:36:36","watched":"1","types":"0"},{"id":"3690","user_id":"4","notification":"Payment Successfully","invoice_id":"374","order_id":"0","status":"1","device_id":"","date":"07/06/2022","time":"13:36:36","watched":"1","types":"0"},{"id":"3691","user_id":"4","notification":"Payment Successfully","invoice_id":"375","order_id":"0","status":"1","device_id":"","date":"07/06/2022","time":"13:41:13","watched":"1","types":"0"},{"id":"3692","user_id":"4","notification":"Payment Successfully","invoice_id":"376","order_id":"0","status":"1","device_id":"","date":"07/06/2022","time":"13:41:13","watched":"1","types":"0"},{"id":"3693","user_id":"4","notification":"Payment Successfully","invoice_id":"377","order_id":"0","status":"1","device_id":"","date":"07/06/2022","time":"13:41:13","watched":"1","types":"0"},{"id":"3694","user_id":"4","notification":"Payment Successfully","invoice_id":"378","order_id":"0","status":"1","device_id":"","date":"08/06/2022","time":"12:55:15","watched":"1","types":"0"},{"id":"3695","user_id":"4","notification":"Payment Successfully","invoice_id":"379","order_id":"0","status":"1","device_id":"","date":"08/06/2022","time":"12:55:15","watched":"1","types":"0"},{"id":"3696","user_id":"4","notification":"Payment Successfully","invoice_id":"380","order_id":"0","status":"1","device_id":"","date":"08/06/2022","time":"12:55:15","watched":"1","types":"0"},{"id":"3713","user_id":"4","notification":"","invoice_id":"366","order_id":"0","status":"1","device_id":"","date":"2022-07-25 10:27 AM","time":"","watched":"1","types":"1"},{"id":"3714","user_id":"4","notification":"","invoice_id":"366","order_id":"0","status":"1","device_id":"","date":"2022-07-25 10:29 AM","time":"","watched":"1","types":"1"},{"id":"3715","user_id":"4","notification":"","invoice_id":"366","order_id":"0","status":"1","device_id":"","date":"2022-07-25 10:29 AM","time":"","watched":"1","types":"1"},{"id":"3716","user_id":"4","notification":"","invoice_id":"380","order_id":"0","status":"1","device_id":"","date":"2022-07-25 10:29 AM","time":"","watched":"1","types":"1"}]

class Notifymodel {
  Notifymodel({
      bool? status, 
      List<Data>? data,}){
    _status = status;
    _data = data;
}

  Notifymodel.fromJson(dynamic json) {
    _status = json['status'];
    if (json['data'] != null) {
      _data = [];
      json['data'].forEach((v) {
        _data?.add(Data.fromJson(v));
      });
    }
  }
  bool? _status;
  List<Data>? _data;
Notifymodel copyWith({  bool? status,
  List<Data>? data,
}) => Notifymodel(  status: status ?? _status,
  data: data ?? _data,
);
  bool? get status => _status;
  List<Data>? get data => _data;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['status'] = _status;
    if (_data != null) {
      map['data'] = _data?.map((v) => v.toJson()).toList();
    }
    return map;
  }

}

/// id : "3126"
/// user_id : "4"
/// notification : "Payment Successfully"
/// invoice_id : "303"
/// order_id : "0"
/// status : "1"
/// device_id : ""
/// date : "19/02/2022"
/// time : "13:20:50"
/// watched : "1"
/// types : "0"

class Data {
  Data({
      String? id, 
      String? userId, 
      String? notification, 
      String? invoiceId, 
      String? orderId, 
      String? status, 
      String? deviceId, 
      String? date, 
      String? time, 
      String? watched, 
      String? types,}){
    _id = id;
    _userId = userId;
    _notification = notification;
    _invoiceId = invoiceId;
    _orderId = orderId;
    _status = status;
    _deviceId = deviceId;
    _date = date;
    _time = time;
    _watched = watched;
    _types = types;
}

  Data.fromJson(dynamic json) {
    _id = json['id'];
    _userId = json['user_id'];
    _notification = json['notification'];
    _invoiceId = json['invoice_id'];
    _orderId = json['order_id'];
    _status = json['status'];
    _deviceId = json['device_id'];
    _date = json['date'];
    _time = json['time'];
    _watched = json['watched'];
    _types = json['types'];
  }
  String? _id;
  String? _userId;
  String? _notification;
  String? _invoiceId;
  String? _orderId;
  String? _status;
  String? _deviceId;
  String? _date;
  String? _time;
  String? _watched;
  String? _types;
Data copyWith({  String? id,
  String? userId,
  String? notification,
  String? invoiceId,
  String? orderId,
  String? status,
  String? deviceId,
  String? date,
  String? time,
  String? watched,
  String? types,
}) => Data(  id: id ?? _id,
  userId: userId ?? _userId,
  notification: notification ?? _notification,
  invoiceId: invoiceId ?? _invoiceId,
  orderId: orderId ?? _orderId,
  status: status ?? _status,
  deviceId: deviceId ?? _deviceId,
  date: date ?? _date,
  time: time ?? _time,
  watched: watched ?? _watched,
  types: types ?? _types,
);
  String? get id => _id;
  String? get userId => _userId;
  String? get notification => _notification;
  String? get invoiceId => _invoiceId;
  String? get orderId => _orderId;
  String? get status => _status;
  String? get deviceId => _deviceId;
  String? get date => _date;
  String? get time => _time;
  String? get watched => _watched;
  String? get types => _types;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = _id;
    map['user_id'] = _userId;
    map['notification'] = _notification;
    map['invoice_id'] = _invoiceId;
    map['order_id'] = _orderId;
    map['status'] = _status;
    map['device_id'] = _deviceId;
    map['date'] = _date;
    map['time'] = _time;
    map['watched'] = _watched;
    map['types'] = _types;
    return map;
  }

}