/// response : true
/// message : "User Register Sucessfully.."

class ParcelDetailsModel{
  RegisterModel({
    bool? response,
    String? message,}){
    _response = response;
    _message = message;
  }

  ParcelDetailsModel.fromJson(dynamic json) {
    _response = json['response'];
    _message = json['message'];
  }
  bool? _response;
  String? _message;
  ParcelDetailsModel copyWith({  bool? response,
    String? message,
  }) => RegisterModel(  response: response ?? _response,
    message: message ?? _message,
  );
  bool? get response => _response;
  String? get message => _message;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['response'] = _response;
    map['message'] = _message;
    return map;
  }

}